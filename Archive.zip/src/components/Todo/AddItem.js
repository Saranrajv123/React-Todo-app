import React, { Component } from 'react';

class AddItem extends Component {

    formSubmitHandler = (e) => {
        e.preventDefault();
        this.props.addItemHandler(this.nameInput.value);

        this.nameInput.value = ''
    }
    render() {
        return (
            
            <form className='col-8' onSubmit={this.formSubmitHandler}>
                
                <div className='row'>
                    <div className='col-md-10'>
                        <input 
                        className='col-md-12 form-control'
                        placeholder='Add item'
                        ref={nameInput => this.nameInput = nameInput}
                        
                        />
                    </div>

                    <div className='col-md-2'>
                    <button className='col-md-12 btn btn-light'>Add</button>

                    </div>
                     
                </div>
               
            </form>
        );
    }
}

export default AddItem;